//
//  ViewController.swift
//  Login
//
//  Created by N. Mompi Devi on 13/05/18.
//  Copyright © 2018 momiv. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var username: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func showMessage(message:String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    @IBAction func tappedOnLogin(_ sender: UIButton) {
        let tempUsername = "mompi"
        let tempPassword = "1234"
        if(username.text == tempUsername && password.text == tempPassword){
//            showMessage(message:"You have succesfully Logged In")
            performSegue(withIdentifier: "GallerySegue", sender: sender)
        }
        else{
            showMessage(message:"You have entered the wrong username or password");
        }
    }
   
    

}

