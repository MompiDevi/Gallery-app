//
//  DetailViewController.swift
//  Login
//
//  Created by N. Mompi Devi on 16/06/18.
//  Copyright © 2018 momiv. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    @IBOutlet weak var imageView: UIImageView!
    var image:UIImage!
    override func viewDidLoad() {
        super.viewDidLoad()
        imageView.image = image
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func tappedOnBack(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
}
