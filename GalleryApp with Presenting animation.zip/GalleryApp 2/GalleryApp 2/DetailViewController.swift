//
//  DetailViewController.swift
//  GalleryApp 2
//
//  Created by N. Mompi Devi on 05/07/18.
//  Copyright © 2018 momiv. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    var image:UIImage?
    @IBOutlet weak var imageView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        imageView.image = image
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func tappedOnBack(_ sender: UIButton) {
        dismiss(animated: true, completion: nil)
    }
}
