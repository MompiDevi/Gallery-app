//
//  CustomTransition.swift
//  GalleryApp 2
//
//  Created by N. Mompi Devi on 08/07/18.
//  Copyright © 2018 momiv. All rights reserved.
//

import UIKit

class CustomTransition: NSObject, UIViewControllerAnimatedTransitioning {
    func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?) -> TimeInterval {
        return 0.5
    }
    
    func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        let fromViewController:ViewController = transitionContext.viewController(forKey: UITransitionContextViewControllerKey.from)! as! ViewController //line 1
        let toViewController:DetailViewController = transitionContext.viewController(forKey: UITransitionContextViewControllerKey.to)! as! DetailViewController //line 2
        let finalFrameForVC = transitionContext.finalFrame(for: toViewController) //line 3
        let containerView = transitionContext.containerView //line 4
        let indexpath = fromViewController.collectionView.indexPathsForSelectedItems?.first //line 5
        let cell = fromViewController.collectionView.cellForItem(at: indexpath!) as! CustomCollectionViewCell //line 6
        let tempImageView = cell.imageView.snapshotView(afterScreenUpdates: false) //line 7
        tempImageView?.frame = containerView.convert(cell.imageView.frame, from: cell.imageView.superview) //line 8
        tempImageView?.contentMode = UIViewContentMode.scaleAspectFit //line 9
        containerView.addSubview(toViewController.view) //line 10
        containerView.addSubview(tempImageView!) //line 11
        toViewController.imageView.isHidden = true //line 12
        UIView.animate(withDuration: 0.5, animations: { //line 13
            tempImageView?.frame = finalFrameForVC //line 14
        }) { (finished) in //line 15
            toViewController.imageView.isHidden = false //line 16
            tempImageView?.removeFromSuperview() //line 17
            transitionContext.completeTransition(true) //line 18
        }
    }
    
    

}
