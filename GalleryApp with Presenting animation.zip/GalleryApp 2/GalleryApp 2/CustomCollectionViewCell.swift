//
//  CustomCollectionViewCell.swift
//  GalleryApp 2
//
//  Created by N. Mompi Devi on 28/06/18.
//  Copyright © 2018 momiv. All rights reserved.
//

import UIKit

class CustomCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
}
