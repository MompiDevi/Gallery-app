//
//  CustomCollectionViewCell.swift
//  Login
//
//  Created by N. Mompi Devi on 03/06/18.
//  Copyright © 2018 momiv. All rights reserved.
//

import UIKit

class CustomCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var image: UIImageView!
}
