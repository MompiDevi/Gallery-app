//
//  CustomTransition.swift
//  Login
//
//  Created by N. Mompi Devi on 10/07/18.
//  Copyright © 2018 momiv. All rights reserved.
//

import UIKit

class CustomTransition: NSObject {

}
