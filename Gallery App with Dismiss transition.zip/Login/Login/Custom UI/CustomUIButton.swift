//
//  CustomUIButton.swift
//  Login
//
//  Created by N. Mompi Devi on 26/05/18.
//  Copyright © 2018 momiv. All rights reserved.
//

import UIKit
@IBDesignable class CustomUIButton: UIButton {
    @IBInspectable
    public var cornerRadius: CGFloat = 2.0 {
        didSet {
            self.layer.cornerRadius = self.cornerRadius
        }
    }
    override func prepareForInterfaceBuilder() {
        self.layer.backgroundColor = UIColor.black.cgColor;
        self.setTitleColor(UIColor.white, for: .normal)
    }
}
