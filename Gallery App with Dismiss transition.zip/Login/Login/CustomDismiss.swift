//
//  CustomDismiss.swift
//  Login
//
//  Created by N. Mompi Devi on 14/07/18.
//  Copyright © 2018 momiv. All rights reserved.
//

import UIKit

class CustomDismiss: NSObject ,UIViewControllerAnimatedTransitioning{
    func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?) -> TimeInterval {
        return 0.5
    }
    
    func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        let fromViewController:DetailViewController = transitionContext.viewController(forKey: UITransitionContextViewControllerKey.from)! as! DetailViewController //line 1
        let toViewController:GalleryViewController = transitionContext.viewController(forKey: UITransitionContextViewControllerKey.to)! as! GalleryViewController //line 2
        let containerView = transitionContext.containerView //line 3
        let indexpath = toViewController.collectionView.indexPathsForSelectedItems?.first //line 4
        let cell = toViewController.collectionView.cellForItem(at: indexpath!) as! CustomCollectionViewCell //line 5
        
        let tempImageView = fromViewController.imageView.snapshotView(afterScreenUpdates: false) //line 6
        tempImageView?.frame = containerView.convert(fromViewController.imageView.frame, from: fromViewController.imageView.superview) //line 7
        tempImageView?.contentMode = UIViewContentMode.scaleAspectFill//line 8
        
        let tempImageView2 = containerView.convert(cell.image.frame, from: cell.image.superview)  //line 9
        
        containerView.addSubview(toViewController.view) //line 10
        containerView.addSubview(tempImageView!)//line 11
        
        let whiteBackground = UIView.init(frame: toViewController.view.frame) //line 12
        whiteBackground.backgroundColor = UIColor.white //line 13
        whiteBackground.alpha = 1 //line 14
        
        containerView.insertSubview(whiteBackground, belowSubview: tempImageView!) //line 15
        cell.alpha = 0.0 //line 16
        fromViewController.imageView.isHidden = false //line 17
        
        UIView.animate(withDuration: 0.5, animations: { //line 18
            tempImageView?.frame = tempImageView2 //line 19
            whiteBackground.alpha = 0.5 //line 20
        }) { (finished) in
            cell.alpha = 1.0 //line 21
            fromViewController.imageView.isHidden = true //line 22
            whiteBackground.removeFromSuperview() //line 23
            tempImageView?.removeFromSuperview() //line 24
            transitionContext.completeTransition(true) //line 25
        }
    }
    

}
